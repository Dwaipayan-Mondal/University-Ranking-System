import pandas as pd

# Step 1: Load the data
file_path = 'IRINS_professor_Database_cleaned.csv'
data = pd.read_csv(file_path)

# Convert department names to lowercase for case-insensitive grouping
data['Department'] = data['Department'].str.lower()

# Step 2: Group by College and Department, and aggregate metrics
grouped = data.groupby(['College', 'Department']).agg({
    'H Index': 'sum',
    'Total Citations': 'sum',
    'Publication': 'sum',
    'Name': 'size'  # Assuming 'Name' column represents the count of professors
}).reset_index()

# Rename 'Name' column to 'ProfCount'
grouped.rename(columns={'Name': 'ProfCount'}, inplace=True)

# Step 3: Calculate total score and normalize
grouped['TotalScore'] = grouped['H Index'] + grouped['Total Citations'] + grouped['Publication']
grouped['NormalizedScore'] = (grouped['TotalScore'] / grouped['ProfCount']).round(2)

# Step 4: Filter out colleges with zero scores
grouped = grouped[grouped['TotalScore'] > 0]

# Step 5: Rank the departments based on normalized score
grouped['Rank'] = grouped.groupby('Department')['NormalizedScore'].rank(ascending=False, method='min')

# Step 6: Sort by rank
grouped = grouped.sort_values(['Rank']).reset_index(drop=True)

# Select and reorder columns
final_df = grouped[['Rank', 'College', 'Department', 'NormalizedScore']]

# Save to a new CSV
output_file = 'department_ranking.csv'
final_df.to_csv(output_file, index=False)

print(f"Ranking has been saved to {output_file}")
