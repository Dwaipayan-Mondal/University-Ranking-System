import pandas as pd
import numpy as np

# Load the CSV file
file_path = 'IRINS_professor_Database_cleaned.csv'
data = pd.read_csv(file_path)

# Replace NA and inf values with 0
data = data.fillna(0)
data = data.replace([np.inf, -np.inf], 0)

# Clean the numeric columns and convert to integers
data['h-index'] = data['H Index']
data['publications'] = data['Publication']
data['citation'] = data['Total Citations']

# Define a function to calculate the Total_Score
def calculate_total_score(row):
    # Calculate the total score by summing h-index, i10-index, and citation
    total_score = row['h-index'] + row['publications'] + row['citation']
    return total_score

# Apply the function to each row to calculate the Total_Score
data['Total_Score'] = data.apply(calculate_total_score, axis=1)

# Calculate the University_Score by summing Total_Score for each University / Institution
university_scores = data.groupby('College')['Total_Score'].sum().reset_index()

# Rename the columns for clarity
university_scores = university_scores.rename(columns={'Total_Score': 'University_Score'})

# Divide University_Score by 3 
university_scores['University_Score'] = (university_scores['University_Score'] / 3).round(2)

# Add a rank column based on the University_Score
university_scores['Rank'] = university_scores['University_Score'].rank(ascending=False, method='min').astype(int)

# Save the data with Total_Score and University_Score to new CSV files
output_file_path_individual = 'Grouped_College_Data.csv'
data.to_csv(output_file_path_individual, index=False)

output_file_path_university = 'University_Scores.csv'
university_scores.to_csv(output_file_path_university, index=False)

print(f"Grouped data with Total_Score has been saved to {output_file_path_individual}")
print(f"University scores with ranks have been saved to {output_file_path_university}")