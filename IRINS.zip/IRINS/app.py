from flask import Flask, render_template, request, redirect, url_for
import pandas as pd

app = Flask(__name__, static_folder='static')

# Load professor data
data_path = 'IRINS_professor_Database_cleaned.csv'
data = pd.read_csv(data_path)

# Load department ranking data
department_ranking_path = 'department_ranking.csv'
department_ranking_data = pd.read_csv(department_ranking_path)

# Load college ranking data
college_ranking_path = 'University_Scores.csv'
college_ranking_data = pd.read_csv(college_ranking_path)

# Clean data (assuming these are your existing cleaning steps)
data['Total Citations'] = data['Total Citations'].fillna(0).astype(int)
data['H Index'] = data['H Index'].fillna(0).astype(int)
data['Publication'] = data['Publication'].fillna(0).astype(int)

# Ensure Rank is an integer
college_ranking_data['Rank'] = college_ranking_data['Rank'].astype(int)

@app.route('/')
def index():
    # Get top 5 professors by each criterion
    top_h_index = data.nlargest(5, 'H Index').to_dict(orient='records')
    top_citations = data.nlargest(5, 'Total Citations').to_dict(orient='records')
    top_publications = data.nlargest(5, 'Publication').to_dict(orient='records')

    # Get top 5 colleges
    top_colleges = college_ranking_data.nsmallest(5, 'Rank').to_dict(orient='records')

    # Get top 5 departments
    top_departments = department_ranking_data.nlargest(5, 'NormalizedScore').to_dict(orient='records')

    # Get top 5 professors by total score
    top_professors = data.nlargest(5, 'Total Score').to_dict(orient='records')

    return render_template('index.html', top_citations=top_citations, top_h_index=top_h_index, top_publications=top_publications, top_colleges=top_colleges, top_departments=top_departments, top_professors=top_professors)

@app.route('/college_ranking')
def college_ranking():
    # Get all college rankings
    colleges = college_ranking_data.nsmallest(len(college_ranking_data), 'Rank').to_dict(orient='records')
    return render_template('college_ranking.html', colleges=colleges)

@app.route('/professor_rankings')
def professor_rankings():
    return render_template('professor_ranking.html', professors=None)

@app.route('/rank_professors', methods=['POST'])
def rank_professors():
    # Get user input for ranking criteria
    criteria = request.form.get('criteria')
    
    # Validate criteria
    if criteria not in ['Total Citations', 'H Index', 'Publication']:
        return redirect(url_for('professor_rankings'))
    
    # Sort data based on selected criteria
    sorted_data = data.sort_values(by=criteria, ascending=False).reset_index(drop=True)
    
    # Add rank column
    sorted_data['Rank'] = sorted_data.index + 1
    
    # Convert to dictionary for template
    ranked_professors = sorted_data.to_dict(orient='records')
    
    # Render template with ranked data
    return render_template('professor_ranking.html', criteria=criteria, professors=ranked_professors)

@app.route('/department_ranking')
def department_ranking():
    departments = department_ranking_data['Department'].unique()
    return render_template('department_ranking.html', departments=departments)

@app.route('/search_department', methods=['POST'])
def search_department():
    department_name = request.form.get('department_name')
    
    # Load department ranking data
    ranking_data = pd.read_csv('department_ranking.csv')
    
    # Filter the data for the specified department
    filtered_data = ranking_data[ranking_data['Department'] == department_name]
    
    # Ensure Rank is an integer
    filtered_data['Rank'] = filtered_data['Rank'].astype(int)
    
    # Convert the filtered data to a dictionary for rendering
    data_dict = filtered_data.to_dict(orient='records')
    
    return render_template('department_ranking_result.html', department_name=department_name, data=data_dict)

@app.route('/contact')
def contact():
    return render_template('contact.html')


if __name__ == '__main__':
    app.run(debug=True)
