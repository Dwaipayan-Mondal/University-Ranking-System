import pandas as pd
from scipy.stats import rankdata

# Load the data 
data_path = 'professors_data.csv'
professors_data = pd.read_csv(data_path)

# Convert the columns to strings first to ensure we can use .str methods
professors_data['citation'] = professors_data['citation'].astype(str)
professors_data['h-index'] = professors_data['h-index'].astype(str)
professors_data['i10-index'] = professors_data['i10-index'].astype(str)

# Remove commas and convert columns to integers
professors_data['citation'] = professors_data['citation'].str.replace(',', '').astype(int)
professors_data['h-index'] = professors_data['h-index'].str.replace(',', '').astype(int)
professors_data['i10-index'] = professors_data['i10-index'].str.replace(',', '').astype(int)

# Group by Subject and calculate the number of professors in each subject
professors_data['num_professors'] = professors_data.groupby('Subject')['Subject'].transform('count')

# Normalize and calculate the score
professors_data['normalized_citation'] = professors_data['citation'] / professors_data['num_professors']
professors_data['normalized_h-index'] = professors_data['h-index'] / professors_data['num_professors']
professors_data['normalized_i10-index'] = professors_data['i10-index'] / professors_data['num_professors']

# Calculate a combined score (equal weights for all metrics)
professors_data['score'] = (professors_data['normalized_citation'] +
                           professors_data['normalized_h-index'] +
                           professors_data['normalized_i10-index']) / 3

# Rank within each subject using scipy.stats.rankdata to ensure ties have the same rank
def compute_rank(group):
    group['rank'] = rankdata(-group['score'], method='dense').astype(int)
    return group

professors_data = professors_data.groupby('Subject').apply(compute_rank)

# Save cleaned and processed data
processed_data_path = 'normalised_data.csv'
professors_data.to_csv(processed_data_path, index=False)

print("Data cleaning and processing complete. Check", processed_data_path, "for the results.")
