import pandas as pd
from scipy.stats import rankdata

# Load the processed data
data_path = 'normalised_data.csv'
professors_data = pd.read_csv(data_path)

# Group by College and Department, then sum the normalized metrics
department_scores = professors_data.groupby(['University / Institution', 'Subject']).agg(
    total_normalized_citation=('normalized_citation', 'sum'),
    total_normalized_h_index=('normalized_h-index', 'sum'),
    total_normalized_i10_index=('normalized_i10-index', 'sum')
).reset_index()

# Calculate the combined score for each department
department_scores['score'] = ((
    department_scores['total_normalized_citation'] +
    department_scores['total_normalized_h_index'] +
    department_scores['total_normalized_i10_index']
) / 3).round(2)

# Rank the colleges department-wise based on the combined score
department_scores['rank'] = department_scores.groupby('Subject')['score'].rank(
    method='dense', ascending=False).astype(int)

# Save the ranked data
ranked_data_path = 'processed_professors_data.csv'
department_scores.to_csv(ranked_data_path, index=False)

print("Department ranking complete. Check", ranked_data_path, "for the results.")

