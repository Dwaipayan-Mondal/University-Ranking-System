from flask import Flask, render_template, request, redirect, url_for
import pandas as pd

app = Flask(__name__, static_folder='static')

# Load data for home page
data = pd.read_csv('professors_data.csv')
data['citation'] = data['citation'].str.replace(',', '').astype(int)
data['i10-index'] = data['i10-index'].str.replace(',', '').astype(int)

# Load data for impact factor
impact_factor_data = pd.read_csv('profile_summary_with_institution.csv')

# Load data for subject-specific rankings
data_path = 'processed_professors_data.csv'
professors_data = pd.read_csv(data_path)
professors_data['rank'] = professors_data['rank'].astype(int)

# Load data for college rankings
colleges_data = pd.read_csv('University_Scores.csv')

def paginate(data, page, per_page):
    start = (page - 1) * per_page
    end = start + per_page
    return data[start:end]

@app.route('/')
def index():
    top_hindex = data.sort_values(by='h-index', ascending=False)[['Name', 'h-index', 'citation', 'i10-index']].head(5).to_dict(orient='records')
    top_citation = data.sort_values(by='citation', ascending=False)[['Name', 'h-index', 'citation', 'i10-index']].head(5).to_dict(orient='records')
    top_i10index = data.sort_values(by='i10-index', ascending=False)[['Name', 'h-index', 'citation', 'i10-index']].head(5).to_dict(orient='records')
    top_departments = professors_data.groupby('Subject')['score'].mean().sort_values(ascending=False).head(5).reset_index().to_dict(orient='records')
    top_colleges = colleges_data.sort_values(by='Rank').head(5)[['University / Institution', 'Rank']].to_dict(orient='records')    
    top_impact_professors = impact_factor_data.sort_values(by='Total_Impact_Factor', ascending=False).head(5).to_dict(orient='records')
    
    subjects = professors_data['Subject'].unique()
    return render_template('index.html', top_hindex=top_hindex, top_citation=top_citation, top_i10index=top_i10index, top_departments=top_departments, top_colleges=top_colleges, top_impact_professors=top_impact_professors, subjects=subjects)

@app.route('/rank', methods=['POST'])
def rank_professors():
    criteria = request.form.get('criteria')
    if criteria == 'impact-factor':
        return redirect(url_for('impact_factor'))
    else:
        sorted_data = data.sort_values(by=criteria, ascending=False).reset_index(drop=True)
        return redirect(url_for('ranked_professors', criteria=criteria, page=1))

@app.route('/ranked_professors', methods=['GET'])
def ranked_professors():
    criteria = request.args.get('criteria')
    page = request.args.get('page', 1, type=int)
    per_page = 5000
    sorted_data = data.sort_values(by=criteria, ascending=False).reset_index(drop=True)
    total = len(sorted_data)
    paginated_data = paginate(sorted_data, page, per_page)
    total_pages = (total + per_page - 1) // per_page
    return render_template('ranked_professors.html', data=paginated_data, criteria=criteria, page=page, total_pages=total_pages)

@app.route('/subject', methods=['GET'])
def subject():
    subject_name = request.args.get('subject_name')
    subject_data = professors_data[professors_data['Subject'] == subject_name].sort_values(by='rank')
    return render_template('subject.html', subject_name=subject_name, professors=subject_data)

@app.route('/professor_rankings')
def professor_rankings():
    subjects = professors_data['Subject'].unique()
    return render_template('professor_ranking.html', subjects=subjects)

@app.route('/professor_rankings_page')
def professor_rankings_page():
    return render_template('professor_rankings_page.html')

@app.route('/impact_factor')
def impact_factor():
    sorted_impact_factor_data = impact_factor_data.sort_values(by='Total_Impact_Factor', ascending=False).reset_index(drop=True)
    sorted_impact_factor_data['Rank'] = sorted_impact_factor_data.index + 1
    return render_template('impact_factor.html', data=sorted_impact_factor_data)

@app.route('/college_rankings')
def college_rankings():
    sorted_colleges = colleges_data.sort_values(by='Rank').reset_index(drop=True)
    return render_template('college_rankings.html', colleges=sorted_colleges)

@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == '__main__':
    app.run(debug=True)
